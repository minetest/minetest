You might have to recompile the engine to get library files in here.
Check the readme.txt in the corresponding bin folders for more information.
